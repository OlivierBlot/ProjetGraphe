%boolean matrix addition
function C=booladd(A,B)
C=double(A+B>0);