clear all
close all

addpath('matlab_bgl');      %load graph libraries
addpath('matlab_tpgraphe'); %load tp ressources

T = table2array(readtable("topology_high.csv"))

n = size(T,1)

sat_id = string(T(1:n,1));
pos = T(1:n,2:end);
D = zeros(n,n);

for i=1:n
    for j=1:n
        D(i,j) = norm([T(i,2)-T(j,2), T(i,3)-T(j,3), T(i,4)-T(j,4) ]);
    end
end

D;
A =ones(n,n);
portee0 = 20000;
for i=1:3
portee = i*portee0
    A = badd(portee*ones(n,n),-D);
    somme_deg = sum(A) - 1;
    deg = sum(somme_deg) / 100
    figure()
    hist(somme_deg)
    title("Distribution du degré")
    clst = clustering_coefficients(sparse(A));
    figure()
    hist(clst)
    title("Distribution du degré de clustering")
    moy_clst = sum(clst)/100
    clique = maximalCliques(A-diag(diag(ones(100))));
    nbr_clq = length(clique(1,:))
    ordre_clq = sum(clique);
    figure()
    hist(ordre_clq)
    title("Nombre de cliques")
    [~ , size_comp] = components(sparse(A))
    
    length(size_comp)
   
    
    size_comp
    viz_adj3D(D,A,pos,sat_id)
end