clear all
close all

addpath('matlab_bgl');      %load graph libraries
addpath('matlab_tpgraphe'); %load tp ressources

T = table2array(readtable("topology_low.csv"))

n = size(T,1)

sat_id = string(T(1:n,1));
pos = T(1:n,2:end);
D = zeros(n,n);

for i=1:n
    for j=1:n
        D(i,j) = norm([T(i,2)-T(j,2), T(i,3)-T(j,3), T(i,4)-T(j,4) ]);
    end
end

D;
A =ones(n,n);
portee0 = 20000;

figure_graphe = ones(3, length(sat_id))
figure_degre = ones(3, length(sat_id))
figure_clustering = ones(3, length(sat_id))
figure_clique = ones(3,77)
figure_repartition_chemin = ones(3, length(sat_id))
figure_nombre_chemin = ones(3, length(sat_id))
figure_moyenne_chemin = ones(3, length(sat_id))

p = 1;

for i=1:3
    
    portee = i*portee0
    A = badd(portee*ones(n,n),-D);
    somme_deg = sum(A) - 1;
    
    deg = sum(somme_deg) / 100
    figure(p);
    hist(somme_deg)
    figure_degre(i,:) = somme_deg
    p = p + 1 ;
    title("Distribution du degré")

    clst = clustering_coefficients(sparse(A));
    figure(p)
    hist(clst)
    title("Distribution du degré de clustering")
    p = p + 1;

    figure_clustering(i,:) = clst
    moy_clst = sum(clst)/100
    clique = maximalCliques(A-diag(diag(ones(100))));
    nbr_clq = length(clique(1,:))
    ordre_clq = sum(clique);
    
    figure(p)
    hist(ordre_clq)
    title("Nombre de cliques")
    p = p + 2;
    [comp, size_comp] = components(sparse(A));
    
    length(size_comp)
   
    
    size_comp
    viz_adj3D(D,A,pos,sat_id)
    j = 2;
   
    [poids, ~]  = shortest_paths(sparse(A), j);
    poids(poids == Inf) = 0
    figure(p)
    hist(poids)
    title("Répartition des plus courts chemin en partant du sommet", j)
    p = p +1;
    figure_repartition_chemin(i,:) = poids
    

    v_mlc = ones(1,length(sat_id));
    X = ones(1,length(sat_id))
    for i=1 : length(poids)
        [poids, ~]  = shortest_paths(sparse(A), i);
        poids(poids == Inf) = 0;
        moy_lgchemin = sum(poids) / length(poids);
        v_mlc(i) = moy_lgchemin;
        X(i) = i-1
    end
    
    
    [poids, ~]  = shortest_paths(sparse(A), j);
    poids(poids == Inf) = 0

    figure(p)
    bar(poids)
    title("Plus court chemin entre tous les sommets et le sommet initial ", j)
    p = p +1;
    figure_nombre_chemin(i,:) = poids

    figure(p)
    plot(X,v_mlc)
    title("Moyenne des plus courts chemins selon le sommet de départ")
    p = p + 1,
    figure_nombre_chemin(i,:) = v_mlc

end


    fig = figure(1 + 7*(i-1));
    sb = subplot(1,3,i);
    copyobj(allchild(get(fig, 'CurrentAxes')), sb )



